

public class MyRoboter extends Roboter {

	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		Position ball = spielHelfer.getBall();
		
		// Ball runter-rechts-dribbeln
		if (ball.y <= Spiel.GOAL1_A.y) {
			return getRunterDribbeln(spielHelfer);
		}

		// Ball hoch-rechts-dribbeln
		if (ball.y >= Spiel.GOAL1_B.y) {
			return getHochDribbeln(spielHelfer);
		}
		
		// ab hier ist der Ball sicher auf einer y-Tor-Linie
		
		// check, ob Schusslinie frei ist
		Position testPosition = new Position();
		testPosition.setTo(ball);
		boolean lineIsFree = true;
		while(testPosition.x >= 0) {
			int index = spielHelfer.getPositionMatchingRoboter(testPosition);
			if (index != -1 && index != roboterIndex) {
				// jemand im Weg und ich bin es nicht
				lineIsFree = false;
				break;
			}
			testPosition.x--;
		}
		
		if (!lineIsFree) {
			// Ball runter- oder hochdribbeln, abh�ngig ob sich der Ball ober- oder unterhalb der Mittel-Querlinie befindet
			if (ball.y <= spielHelfer.getMittelpunkt().y) {
				return getRunterDribbeln(spielHelfer);
			}

			// Ball hochdribbeln
			return getHochDribbeln(spielHelfer);
		}

		// In Schussposition bringen
		Position schussPosition = spielHelfer.calcPosition(ball, Kommando.LEFT);
		Kommando laufKommando = spielHelfer.calcRichtung(position, schussPosition);
		if (laufKommando != null) {
			Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
			// avoid moving the ball into the wrong direction while running to schussPosition
			if (spielHelfer.getBall().machtes(laufPosition)) {
				return spielHelfer.dreheRechts(laufKommando);
			}
			if (!spielHelfer.isPositionObstacle(laufPosition)) {
				return laufKommando;
			}
			// Feld ist belegt -> umlaufen
			return spielHelfer.dreheRechts(laufKommando);
		}
		return Kommando.KICK;
	}

	private Kommando getHochDribbeln(SpielHelfer spielHelfer) {
		Position dribblingPosition = spielHelfer.calcPosition(spielHelfer.getBall(), Kommando.LEFT_DOWN);
		Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
		if (kommando != null) {
			return dreheLinksWennBelegt(spielHelfer, kommando);
		}
		return dreheLinksWennBelegt(spielHelfer, Kommando.RIGHT_UP);
	}

	private Kommando getRunterDribbeln(SpielHelfer spielHelfer) {
		Position dribblingPosition = spielHelfer.calcPosition(spielHelfer.getBall(), Kommando.LEFT_UP);
		Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
		if (kommando != null) {
			return dreheLinksWennBelegt(spielHelfer, kommando);
		}
		return dreheLinksWennBelegt(spielHelfer, Kommando.RIGHT_DOWN);
	}

	private Kommando dreheRechtsWennBelegt(SpielHelfer spielHelfer, Kommando laufKommando) {
		Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
		if (!spielHelfer.isPositionObstacle(laufPosition)) {
			return laufKommando;
		}
		// Feld ist belegt -> umlaufen
		return spielHelfer.dreheRechts(laufKommando);
	}

	private Kommando dreheLinksWennBelegt(SpielHelfer spielHelfer, Kommando laufKommando) {
		Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
		if (!spielHelfer.isPositionObstacle(laufPosition)) {
			return laufKommando;
		}
		// Feld ist belegt -> umlaufen
		return spielHelfer.dreheLinks(laufKommando);
	}

	@Override
	public Position getStartPosition(SpielHelfer spielHelfer) {
		position.setTo(spielHelfer.getMittelpunkt());
		position.x -= 1;
		return position;
	}

	@Override
	public Schwierigkeit getSchwierigkeit() {
		return Schwierigkeit.USER1;
	}
	
}
