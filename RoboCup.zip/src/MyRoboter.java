

public class MyRoboter extends Roboter {
	@Override
	public Schwierigkeit getSchwierigkeit() {
		return Schwierigkeit.S3_SCHIESST_TOR;
	}
	
	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		return null;
	}

	@Override
	public Position getStartPosition(SpielHelfer spielHelfer) {
		return null;
	}
}
