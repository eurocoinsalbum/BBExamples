
public class RoboterS2StehtRum extends Roboter {

	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		return null;
	}

	@Override
	public Position getStartPosition(SpielHelfer spielHelfer) {
		position.setTo(spielHelfer.getMittelpunkt());
		position.x += 6;
		return position;
	}

	@Override
	public Schwierigkeit getSchwierigkeit() {
		return null;
	}
}
