
public class Main {

	public static void main(String[] args) {
		Roboter roboter = new User1();
		Spiel spiel = new Spiel();
		spiel.addRoboter(roboter);
		Schwierigkeit schwierigkeit = roboter.getSchwierigkeit();
		if (schwierigkeit == null) {
			schwierigkeit = Schwierigkeit.USER2;
		}
		
		if (schwierigkeit == Schwierigkeit.S1_KEIN_GEGNER) {
			// kein Gegner
		} else if (schwierigkeit == Schwierigkeit.S2_STEHT_RUM) {
			spiel.addRoboter(new RoboterS2StehtRum());
		} else if (schwierigkeit == Schwierigkeit.S3_SCHIESST_TOR) {
			spiel.addRoboter(new RoboterS3SchiesstTor());
		} else if (schwierigkeit == Schwierigkeit.S4_DRIBBELT) {
			spiel.addRoboter(new RoboterS4Dribbelt());
		} else if (schwierigkeit == Schwierigkeit.USER1) {
			spiel.addRoboter(new User1());
		} else if (schwierigkeit == Schwierigkeit.USER2) {
			spiel.addRoboter(new User2());
		} else if (schwierigkeit == Schwierigkeit.USER3) {
			spiel.addRoboter(new User3());
		} else if (schwierigkeit == Schwierigkeit.USER4) {
			spiel.addRoboter(new User4());
		}
		spiel.start();
	}

}
