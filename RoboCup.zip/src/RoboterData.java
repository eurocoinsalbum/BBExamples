
public class RoboterData {
	public int power;
	public Position position = new Position();
}
