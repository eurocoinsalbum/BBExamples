
public abstract class Roboter {
	public int power = 0;
	public Position position = new Position();
	public int roboterIndex = -1;
	
	public Kommando getKommando(SpielHelfer spielHelfer) {
		return null;
	}
	
	public abstract Position getStartPosition(SpielHelfer spielHelfer);
	
	public abstract Schwierigkeit getSchwierigkeit();
}