

public class RoboterS3SchiesstTor extends Roboter {

	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		Position ball = spielHelfer.getBall();
		
		// Ball runter-rechts-dribbeln
		if (ball.y <= Spiel.GOAL1_A.y) {
			Position dribblingPosition = spielHelfer.calcPosition(ball, Kommando.RIGHT_UP);
			Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
			if (kommando != null) {
				return dreheLinksWennBelegt(spielHelfer, kommando);
			}
			return dreheLinksWennBelegt(spielHelfer, Kommando.LEFT_DOWN);
		}

		// Ball hoch-rechts-dribbeln
		if (ball.y >= Spiel.GOAL1_B.y) {
			Position dribblingPosition = spielHelfer.calcPosition(ball, Kommando.RIGHT_DOWN);
			Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
			if (kommando != null) {
				return dreheLinksWennBelegt(spielHelfer, kommando);
			}
			return dreheLinksWennBelegt(spielHelfer, Kommando.LEFT_UP);
		}
		
		// In Schussposition bringen
		Position schussPosition = spielHelfer.calcPosition(ball, Kommando.RIGHT);
		Kommando laufKommando = spielHelfer.calcRichtung(position, schussPosition);
		if (laufKommando != null) {
			Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
			// avoid moving the ball into the wrong direction while running to schussPosition
			if (spielHelfer.getBall().machtes(laufPosition)) {
				return spielHelfer.dreheLinks(laufKommando);
			}
			if (!spielHelfer.isPositionObstacle(laufPosition)) {
				return laufKommando;
			}
			// Feld ist belegt -> umlaufen
			return spielHelfer.dreheLinks(laufKommando);
		}
		return Kommando.KICK;
	}

	private Kommando dreheLinksWennBelegt(SpielHelfer spielHelfer, Kommando laufKommando) {
		Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
		if (!spielHelfer.isPositionObstacle(laufPosition)) {
			return laufKommando;
		}
		// Feld ist belegt -> umlaufen
		return spielHelfer.dreheLinks(laufKommando);
	}

	@Override
	public Position getStartPosition(SpielHelfer spielHelfer) {
		position.setTo(spielHelfer.getMittelpunkt());
		position.x += 3;
		return position;
	}

	@Override
	public Schwierigkeit getSchwierigkeit() {
		return null;
	}
	
}
