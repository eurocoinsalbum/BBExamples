
public class Position {
	public int x;
	public int y;
	public boolean machtes(Position position) {
		if (x != position.x) {
			return false;
		}
		
		if (y != position.y) {
			return false;
		}
		
		return true;
	}
	public void setTo(Position position) {
		x = position.x;
		y = position.y;
	}
}
