import java.util.Scanner;

public class User2 extends Roboter {
	int i = 0;
	@Override
	public Schwierigkeit getSchwierigkeit() {
		return null;
	}
	
	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		Position lvb = new Position();
		lvb.setTo(spielHelfer.getBall());
		lvb.x -=1;
		if (position.machtes(lvb) && position.x > spielHelfer.getSizeX() - 5){
			return Kommando.KICK;
		}
		Position ovb = new Position();
		ovb.setTo(spielHelfer.getBall());
		ovb.y -= 1;		
		
		if (position.machtes(ovb)){
			Position rvb = new Position();
			rvb.setTo(spielHelfer.getBall());
			rvb.x += 1;
			if (spielHelfer.getRoboterData(1).position.machtes(rvb)){
				return Kommando.DOWN;
			}
		}
		Position zielFeld2 = new Position();
		zielFeld2.setTo(spielHelfer.getBall());
		zielFeld2.x -= 1;
		Kommando command = spielHelfer.calcRichtung(position, zielFeld2);
		if (command == null) {
			Position zielFeld = new Position();
			zielFeld.setTo(spielHelfer.getBall());
			zielFeld.x += 1;
			
			if (spielHelfer.isFreeValidPosition(zielFeld)) {
				return Kommando.RIGHT;
			}
			Position zielFeld3 = new Position();
			zielFeld3.setTo(spielHelfer.getBall());
			zielFeld3.y -= 1;
			Kommando command2 = spielHelfer.calcRichtung(position, zielFeld3);
			return command2;
		}
		
		return command;
	}

	@Override
	public Position getStartPosition(SpielHelfer spielHelfer) {
		i = 0;
		return null;
	}
}