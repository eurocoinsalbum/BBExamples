
public class SpielHelfer {
	private Spiel spiel;

	public SpielHelfer(Spiel spiel) {
		this.spiel = spiel;
	}

	public static Position createPosition(int y, int x) {
		Position position = new Position();
		position.x = x;
		position.y = y;
		return position;
	}

	public boolean isPositionOutside(Position position) {
		if (position.x < 0) {
			return true;
		}
		if (position.x >= Spiel.SIZE_X) {
			return true;
		}
		if (position.y < 0) {
			return true;
		}
		if (position.y >= Spiel.SIZE_Y) {
			return true;
		}
		return false;
	}

	public boolean isPositionGoal(Position position) {
		if (position.machtes(Spiel.GOAL1_A)) {
			return true;
		}
		if (position.machtes(Spiel.GOAL1_B)) {
			return true;
		}
		if (position.machtes(Spiel.GOAL2_A)) {
			return true;
		}
		if (position.machtes(Spiel.GOAL2_B)) {
			return true;
		}
		return false;
	}

	public int getPositionMatchingRoboter(Position position) {
		for (int i = 0; i < spiel.anzahlRoboter; i++) {
			if (position.machtes(spiel.roboterDatas[i].position)) {
				return i;
			}
		}
		return -1;
	}

	public boolean isPositionObstacle(Position position) {
		if (getPositionMatchingRoboter(position) != -1) {
			return true;
		}
		if (isPositionGoal(position)) {
			return true;
		}
		return false;
	}
	
	/**
	 * the returned position might be outside the pitch (not more than 1 field)!
	 */
	public Position calcPosition(Position position, Kommando kommando) {
		Position calcedPosition = new Position();
		calcedPosition.setTo(position);
		if (kommando == Kommando.LEFT) {
			if (calcedPosition.x >= 0) {
				calcedPosition.x--;
			}
		}
		if (kommando == Kommando.LEFT_UP) {
			if (calcedPosition.x >= 0 && calcedPosition.y >= 0) {
				calcedPosition.x--;
				calcedPosition.y--;
			}
		}
		if (kommando == Kommando.UP) {
			if (calcedPosition.y >= 0) {
				calcedPosition.y--;
			}
		}
		if (kommando == Kommando.RIGHT_UP) {
			if (calcedPosition.x <= Spiel.SIZE_X - 1 && calcedPosition.y >= 0) {
				calcedPosition.x++;
				calcedPosition.y--;
			}
		}
		if (kommando == Kommando.RIGHT) {
			if (calcedPosition.x <= Spiel.SIZE_X - 1) {
				calcedPosition.x++;
			}
		}
		if (kommando == Kommando.RIGHT_DOWN) {
			if (calcedPosition.x <= Spiel.SIZE_X - 1 && calcedPosition.y <= Spiel.SIZE_Y - 1) {
				calcedPosition.x++;
				calcedPosition.y++;
			}
		}
		if (kommando == Kommando.DOWN) {
			if (calcedPosition.y <= Spiel.SIZE_Y - 1) {
				calcedPosition.y++;
			}
		}
		if (kommando == Kommando.LEFT_DOWN) {
			if (calcedPosition.x >= 0 && calcedPosition.y <= Spiel.SIZE_Y - 1) {
				calcedPosition.x--;
				calcedPosition.y++;
			}
		}
		return calcedPosition;
	}

	public Kommando getCommandoForKick(Position pos) {
		for (int y = pos.y - 1; y <= pos.y + 1; y++) {
			for (int x = pos.x - 1; x <= pos.x + 1; x++) {
				Position position = SpielHelfer.createPosition(y, x);
				if (!position.machtes(spiel.ball)) {
					continue;
				}
				
				if (y < pos.y) {
					if (x < pos.x) {
						return Kommando.LEFT_UP;
					}
					if (x > pos.x) {
						return Kommando.RIGHT_UP;
					}
					return Kommando.UP;
				}

				if (y > pos.y) {
					if (x < pos.x) {
						return Kommando.LEFT_DOWN;
					}
					if (x > pos.x) {
						return Kommando.RIGHT_DOWN;
					}
					return Kommando.DOWN;
				}
				if (x < pos.x) {
					return Kommando.LEFT;
				}
				return Kommando.RIGHT;
			}
		}
		return null;
	}

	public Position getBall() {
		return spiel.ball;
	}

	public Kommando calcRichtung(Position vonPosition, Position nachPosition) {
		if (vonPosition.x > nachPosition.x) {
			if (vonPosition.y > nachPosition.y) {
				return Kommando.LEFT_UP;
			}
			if (vonPosition.y < nachPosition.y) {
				return Kommando.LEFT_DOWN;
			}
			return Kommando.LEFT;
		}
		
		if (vonPosition.x < nachPosition.x) {
			if (vonPosition.y > nachPosition.y) {
				return Kommando.RIGHT_UP;
			}
			if (vonPosition.y < nachPosition.y) {
				return Kommando.RIGHT_DOWN;
			}
			return Kommando.RIGHT;
		}
		
		if (vonPosition.y > nachPosition.y) {
			return Kommando.UP;
		}
		if (vonPosition.y < nachPosition.y) {
			return Kommando.DOWN;
		}

		return null;
	}

	public RoboterData getRoboterData(int index) {
		return spiel.roboterDatas[index];
	}
	
	public int getTore(int team) {
		if (team == 0) {
			return spiel.toreTeam1;
		}
		return spiel.toreTeam2;
	}
	
	public long getRestzeit() {
		return (spiel.spielEnde.getTime() - System.currentTimeMillis()) / 1000; 
	}
	
	public Kommando dreheRechts(Kommando kommando) {
		if (kommando == Kommando.LEFT) {
			return Kommando.LEFT_UP;
		}
		if (kommando == Kommando.LEFT_UP) {
			return Kommando.UP;
		}
		if (kommando == Kommando.UP) {
			return Kommando.RIGHT_UP;
		}
		if (kommando == Kommando.RIGHT_UP) {
			return Kommando.RIGHT;
		}
		if (kommando == Kommando.RIGHT) {
			return Kommando.RIGHT_DOWN;
		}
		if (kommando == Kommando.RIGHT_DOWN) {
			return Kommando.DOWN;
		}
		if (kommando == Kommando.DOWN) {
			return Kommando.LEFT_DOWN;
		}
		return Kommando.LEFT;
	}

	public Kommando dreheLinks(Kommando kommando) {
		if (kommando == Kommando.LEFT) {
			return Kommando.LEFT_DOWN;
		}
		if (kommando == Kommando.LEFT_DOWN) {
			return Kommando.DOWN;
		}
		if (kommando == Kommando.DOWN) {
			return Kommando.RIGHT_DOWN;
		}
		if (kommando == Kommando.RIGHT_DOWN) {
			return Kommando.RIGHT;
		}
		if (kommando == Kommando.RIGHT) {
			return Kommando.RIGHT_UP;
		}
		if (kommando == Kommando.RIGHT_UP) {
			return Kommando.UP;
		}
		if (kommando == Kommando.UP) {
			return Kommando.LEFT_UP;
		}
		return Kommando.LEFT;
	}

	public int getSizeY() {
		return Spiel.SIZE_Y;
	}		

	public int getSizeX() {
		return Spiel.SIZE_X;
	}
	
	public Position getMittelpunkt() {
		return createPosition(Spiel.SIZE_Y / 2,	Spiel.SIZE_X / 2);
	}

	public int getAnzahlRoboter() {
		return spiel.anzahlRoboter;
	}

	public boolean isFreeValidPosition(Position position) {
		if (isPositionOutside(position)) {
			return false;
		}
		if (isPositionObstacle(position)) {
			return false;
		}
		return true;
	}
}