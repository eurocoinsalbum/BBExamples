import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JComponent;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Spielfeld2D extends JFrame {
	private SpielfeldCanvas spielfeldCanvas;
	public static int IMG_SIZE = 48;
	
	public Spielfeld2D() {
		super("BBSpielfeld");
		spielfeldCanvas = new SpielfeldCanvas();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, (Spiel.SIZE_X + 4) * IMG_SIZE, (Spiel.SIZE_Y + 3) * IMG_SIZE);
		getContentPane().add(spielfeldCanvas);
		setVisible(true);
	}
	
	public void zeichne(SpielHelfer spielHelfer) {
		spielfeldCanvas.spielHelfer = spielHelfer;
		spielfeldCanvas.repaint();
	}
	
	private class SpielfeldCanvas extends JComponent {
		public SpielHelfer spielHelfer;
		private Image[] images = new Image[7];
		private static final int IMG_WIESE = 0;
		private static final int IMG_FUSSBALL = 1;
		private static final int IMG_TOR1 = 2;
		private static final int IMG_TOR2 = 3;
		private static final int IMG_FAHNE = 4;
		private static final int IMG_SPIELER_1 = 5;
		private static final int IMG_SPIELER_2 = 6;
		private Position ecke1 = SpielHelfer.createPosition(0, 0);
		private Position ecke2 = SpielHelfer.createPosition(0, Spiel.SIZE_X - 1);
		private Position ecke3 = SpielHelfer.createPosition(Spiel.SIZE_Y - 1, 0);
		private Position ecke4 = SpielHelfer.createPosition(Spiel.SIZE_Y - 1, Spiel.SIZE_X - 1);

		public SpielfeldCanvas() {
			images[IMG_WIESE] = Toolkit.getDefaultToolkit().getImage(getClass().getResource("wiese.png"));
			images[IMG_FUSSBALL] = Toolkit.getDefaultToolkit().getImage(getClass().getResource("icons8-fussball.png"));
			images[IMG_TOR1] = Toolkit.getDefaultToolkit().getImage(getClass().getResource("icons8-fussballtor1.png"));
			images[IMG_TOR2] = Toolkit.getDefaultToolkit().getImage(getClass().getResource("icons8-fussballtor2.png"));
			images[IMG_FAHNE] = Toolkit.getDefaultToolkit().getImage(getClass().getResource("icons8-flag-gefuellt.png"));
			images[IMG_SPIELER_1] = Toolkit.getDefaultToolkit().getImage(getClass().getResource("icons8-stehender-mann.png"));
			images[IMG_SPIELER_2] = Toolkit.getDefaultToolkit().getImage(getClass().getResource("icons8-stehender-mann-filled.png"));
		}

		public void paint(Graphics g) {
			Graphics2D g2 = (Graphics2D)g;
			
			// �berall Wiese
			for (int y = -2; y <= Spiel.SIZE_Y; y++) {
				for (int x = -2; x < Spiel.SIZE_X + 2; x++) {
					Position position = SpielHelfer.createPosition(y, x);
					paintImage(g2, images[IMG_WIESE], position);
				}
			}
			
			// Linien
			g2.setColor(Color.WHITE);
			g2.setStroke(new BasicStroke(10));
			int x = IMG_SIZE * 2 + IMG_SIZE / 2;
			int y = IMG_SIZE + IMG_SIZE / 2;
			int width = IMG_SIZE * (Spiel.SIZE_X - 1);
			int height = IMG_SIZE * (Spiel.SIZE_Y - 1);
			g2.drawRect(x, y, width, height);
			g2.drawLine(x + width / 2, y, x + width / 2, y + height);
			int umfangMittelkreis = 3 * IMG_SIZE;
			g2.drawOval((int) (x + (float)width / 2 - umfangMittelkreis / 2), (int) (y + (float)height / 2 - umfangMittelkreis / 2), umfangMittelkreis, umfangMittelkreis);

			// Eckfahnen
			paintImage(g2, images[IMG_FAHNE], ecke1);
			paintImage(g2, images[IMG_FAHNE], ecke2);
			paintImage(g2, images[IMG_FAHNE], ecke3);
			paintImage(g2, images[IMG_FAHNE], ecke4);
			
			// Tore
			g2.drawImage(images[IMG_TOR1], (int)((float)(Spiel.GOAL1_A.x + 0.5) * IMG_SIZE), (Spiel.GOAL1_A.y + 1) * IMG_SIZE, this);
			g2.drawImage(images[IMG_TOR2], (int)((float)(Spiel.GOAL2_A.x + 2.5) * IMG_SIZE), (Spiel.GOAL2_A.y + 1) * IMG_SIZE, this);

			// Ball
			paintImage(g2, images[IMG_FUSSBALL], spielHelfer.getBall());
			
			// Spieler
			paintImage(g2, images[IMG_SPIELER_1], spielHelfer.getSpieler(0));
			if (spielHelfer.getAnzahlRoboter() > 1) {
				paintImage(g2, images[IMG_SPIELER_2], spielHelfer.getSpieler(1));
			}
			
			// Spielstand
			String spielStandUhrzeit = spielHelfer.getTore(0) + ":" + spielHelfer.getTore(1) + "  " + spielHelfer.getRestzeit();
			g2.drawString(String.valueOf(spielStandUhrzeit), 0, 20);

			g2.drawString("All Icons by www.icons8.de", 0, (Spiel.SIZE_Y + 2) * IMG_SIZE - 50);
			g2.finalize();
		}

		private void paintImage(Graphics2D g2, Image image, Position position) {
			g2.drawImage(image, (position.x + 2) * IMG_SIZE, (position.y + 1) * IMG_SIZE, this);
		}
	}
}
