
public class RoboterS2StehtRum implements RoboterInterface {
	private final Position position = new Position();
	
	@Override
	public Position getPosition() {
		return position;
	}

	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		return null;
	}

	@Override
	public void goToStartPosition(SpielHelfer spielHelfer) {
		position.setTo(spielHelfer.getMittelpunkt());
		position.x += 6;
	}

	@Override
	public Schwierigkeit getSchwierigkeit() {
		return null;
	}

	@Override
	public void setIndex(int index) {
	}

}
