import java.util.Date;

public class Spiel {
	private static final long THROTTLING = 500;
	private static final int GOAL_NO = 0;
	private static final int GOAL_TEAM1 = 1;
	private static final int GOAL_TEAM2 = 2;
	private static int SPIELDAUER = 30;

	public static int SIZE_X = 21;
	public static int SIZE_Y = 11;
	public static Position GOAL1_A = SpielHelfer.createPosition(3, 0);
	public static Position GOAL1_B = SpielHelfer.createPosition(7, 0);
	public static Position GOAL2_A = SpielHelfer.createPosition(3, SIZE_X - 1);
	public static Position GOAL2_B = SpielHelfer.createPosition(7, SIZE_X - 1);
	RoboterInterface[] roboterListe = new RoboterInterface[2];
	Position ball;
	int anzahlRoboter;
	private SpielHelfer spielHelfer = new SpielHelfer(this);
	private Spielfeld2D spielfeld2D = new Spielfeld2D();
	int toreTeam1;
	int toreTeam2;
	Date spielEnde;

	public void addRoboter(RoboterInterface roboter) {
		roboterListe[anzahlRoboter] = roboter;
		roboter.setIndex(anzahlRoboter);
		anzahlRoboter++;
	}

	public void start() {
		initSpiel();
		
		spielEnde = new Date(System.currentTimeMillis() + SPIELDAUER * 1000);
		druckeSpielfeld();
		while (spielEnde.after(new Date())) {
			int goalId = rechne();
			druckeSpielfeld();
			if (goalId != GOAL_NO) {
				goalScored(goalId);
				continue;
			}
		}
	}

	private void initSpiel() {
		toreTeam1 = 0;
		toreTeam2 = 0;
		initStartaufstellung();
	}

	private void initStartaufstellung() {
		ball = spielHelfer.getMittelpunkt();
		// init position of every robot
		for (int i = 0; i < anzahlRoboter; i++) {
			RoboterInterface roboter = roboterListe[i];
			roboter.goToStartPosition(spielHelfer);
			// check if robot's position is on the correct side of the field
			if (i == 0 && roboter.getPosition().x > SIZE_X / 2) {
				// roboter is on the wrong side - force him to his side
				roboter.getPosition().setTo(spielHelfer.calcPosition(ball, Kommando.LEFT));
			}
		}
	}

	private void druckeSpielfeld() {
		for (int y = -1; y <= SIZE_Y; y++) {
			for (int x = -1; x <= SIZE_X; x++) {
				// Ball
				Position position = SpielHelfer.createPosition(y, x);
				if (position.machtes(ball)) {
					System.out.print("o");
					continue;
				}
				
				// One of the robots
				boolean roboterFound = false;
				for (int i = 0; i < anzahlRoboter; i++) {
					if (position.machtes(roboterListe[i].getPosition())) {
						System.out.print("X");
						roboterFound = true;
						break;
					}
				}
				if (roboterFound) {
					continue;
				}
				
				// Goals
				if (spielHelfer.isPositionGoal(position)) {
					System.out.print("+");
					continue;
				}
				
				if (y == 0 || y == SIZE_Y - 1) {
					if (x == 0 || x == SIZE_X - 1) {
						System.out.print("*");
						continue;
					}
					if (x > 0 && x < SIZE_X - 1) {
						System.out.print("-");
						continue;
					}
				}
				
				if (((y > 0 && y < GOAL1_A.y) || (y > GOAL1_B.y && y < SIZE_Y - 1)) && (x == 0 || x == SIZE_X - 1)) {
					System.out.print("|");
					continue;					
				}
				
				if ((x < 0 || x >= SIZE_X) && y >= GOAL1_A.y && y <= GOAL1_B.y) {
					System.out.print("#");
					continue;
				}
				System.out.print(" ");
			}
			System.out.println("");
		}
		spielfeld2D.zeichne(spielHelfer);
		warte(THROTTLING);
	}

	private int rechne() {
		// first: get all requested positions (via command)
		Position[] requestedPositions = new Position[roboterListe.length];
		Kommando[] requestedKommandos = new Kommando[roboterListe.length];

		for (int i = 0; i < anzahlRoboter; i++) {
			RoboterInterface roboter = roboterListe[i];
			requestedKommandos[i] = roboter.getKommando(spielHelfer);
			requestedPositions[i] = spielHelfer.calcPosition(roboter.getPosition(), requestedKommandos[i]);
		}
		
		// check for kicks
		for (int i = 0; i < anzahlRoboter; i++) {
			if  (requestedKommandos[i] == Kommando.KICK) {
				int goalId = tryKickBall(roboterListe[i]);
				if (goalId != GOAL_NO) {
					return goalId;
				}
			}
		}

		// check if there is a clash of requested positions
		for (int i = 0; i < anzahlRoboter; i++) {
			boolean canMove = true;
			for (int j = 0; j < anzahlRoboter; j++) {
				if (i == j) {
					// don't check against our self
					continue;
				}
				if (requestedPositions[i].machtes(requestedPositions[j])) {
					// Zweikampf
					int looser = j;
					if (Math.random() < 0.5) {
						looser = i;
						canMove = false;
					}
					requestedPositions[looser].setTo(roboterListe[looser].getPosition());
					requestedKommandos[looser] = null;
				}
			}
			if (canMove) {
				// check for dribbling
				if (ball.machtes(requestedPositions[i])) {
					Position dribblingPosBall = spielHelfer.calcPosition(requestedPositions[i], requestedKommandos[i]);
					if (isGoal(dribblingPosBall) != GOAL_NO || spielHelfer.isFreeValidPosition(dribblingPosBall)) {
						ball.setTo(dribblingPosBall);
						roboterListe[i].getPosition().setTo(requestedPositions[i]);
						int goalId = isGoal(dribblingPosBall);
						if (goalId != GOAL_NO) {
							return goalId;
						}
					}
				} else {
					// just move robot
					roboterListe[i].getPosition().setTo(requestedPositions[i]);
				}
			}
		}
		return GOAL_NO;
	}
	
	private int tryKickBall(RoboterInterface roboter) {
		Kommando ballKommando = spielHelfer.getCommandoForKick(roboter.getPosition());
		if (ballKommando == null) {
			return GOAL_NO;
		}
		
		// move ball 3 fields across the pitch
		for (int i = 0; i < 3; i++) {
			Position requestedBallPosition = spielHelfer.calcPosition(ball, ballKommando);
			int goalId = isGoal(requestedBallPosition);
			if (goalId != 0) {
				ball.setTo(requestedBallPosition);
				return goalId;
			}
			
			if (!spielHelfer.isFreeValidPosition(requestedBallPosition)) {
				continue;
			}
			
			ball.setTo(requestedBallPosition);
		}
		return GOAL_NO;
	}

	private int isGoal(Position position) {
		if (position.x < 0 && position.y > GOAL1_A.y && position.y < GOAL1_B.y) {
			return GOAL_TEAM2;
		}
		if (position.x > SIZE_X - 1 && position.y > GOAL2_A.y && position.y < GOAL2_B.y) {
			return GOAL_TEAM1;
		}
		return GOAL_NO;
	}

	private void goalScored(int goalId) {
		System.out.println("TOR!!!!");
		if (goalId == GOAL_TEAM1) {
			toreTeam1++;
		} else {
			toreTeam2++;
		}
		warte(1000);
		initStartaufstellung();
		druckeSpielfeld();
		warte(1000);
		druckeSpielfeld();
	}

	private void warte(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
		}

	}
}
