
public interface RoboterInterface {
	Position getPosition();
	Kommando getKommando(SpielHelfer spielHelfer);
	void goToStartPosition(SpielHelfer spielHelfer);
	Schwierigkeit getSchwierigkeit();
	void setIndex(int anzahlRoboter);
}