

public class Roboter implements RoboterInterface {
	private final Position position = new Position();
	private int myIndex;

	@Override
	public Schwierigkeit getSchwierigkeit() {
		return Schwierigkeit.S4_DRIBBELT;
	}
	
	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		Position ball = spielHelfer.getBall();
		
		// Ball runterdribbeln
		if (ball.y <= Spiel.GOAL2_A.y) {
			return getRunterDribbeln(spielHelfer);
		}

		// Ball hochdribbeln
		if (ball.y >= Spiel.GOAL2_B.y) {
			return getHochDribbeln(spielHelfer);
		}
		
		// ab hier ist der Ball sicher auf y-Tor-Linie
		
		// check, ob Schusslinie frei ist
		Position testPosition = new Position();
		testPosition.setTo(ball);
		boolean lineIsFree = true;
		while(testPosition.x < spielHelfer.getSizeX()) {
			int roboterIndex = spielHelfer.getPositionMatchingRoboter(testPosition);
			if (roboterIndex != -1 && roboterIndex != myIndex) {
				// jemand im Weg und ich bin es nicht
				lineIsFree = false;
				break;
			}
			testPosition.x++;
		}
		
		if (!lineIsFree) {
			// Ball runter- oder hochdribbeln, abh�ngig ob sich der Ball ober- oder unterhalb der Mittel-Querlinie befindet
			if (ball.y <= spielHelfer.getMittelpunkt().y) {
				return dreheRechtsWennBelegt(spielHelfer, getRunterDribbeln(spielHelfer));
			}

			// Ball hochdribbeln
			return dreheLinksWennBelegt(spielHelfer, getHochDribbeln(spielHelfer));
		}
		
		// In Schussposition bringen
		Position schussPosition = spielHelfer.calcPosition(ball, Kommando.LEFT);
		Kommando laufKommando = spielHelfer.calcRichtung(position, schussPosition);
		if (laufKommando != null) {
			Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
			// avoid moving the ball into the wrong direction while running to schussPosition
			if (spielHelfer.getBall().machtes(laufPosition)) {
				return spielHelfer.dreheRechts(laufKommando);
			}
			if (!spielHelfer.isPositionObstacle(laufPosition)) {
				return laufKommando;
			}
			// Feld ist belegt -> umlaufen
			return spielHelfer.dreheRechts(laufKommando);
		}
		return Kommando.KICK;
	}

	private Kommando getHochDribbeln(SpielHelfer spielHelfer) {
		Position dribblingPosition = spielHelfer.calcPosition(spielHelfer.getBall(), Kommando.LEFT_DOWN);
		Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
		if (kommando != null) {
			return dreheRechtsWennBelegt(spielHelfer, kommando);
		}
		return dreheRechtsWennBelegt(spielHelfer, Kommando.RIGHT_UP);
	}

	private Kommando getRunterDribbeln(SpielHelfer spielHelfer) {
		Position dribblingPosition = spielHelfer.calcPosition(spielHelfer.getBall(), Kommando.LEFT_UP);
		Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
		if (kommando != null) {
			return dreheRechtsWennBelegt(spielHelfer, kommando);
		}
		return dreheRechtsWennBelegt(spielHelfer, Kommando.RIGHT_DOWN);
	}

	private Kommando dreheRechtsWennBelegt(SpielHelfer spielHelfer, Kommando laufKommando) {
		Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
		if (!spielHelfer.isPositionObstacle(laufPosition)) {
			return laufKommando;
		}
		// Feld ist belegt -> umlaufen
		return spielHelfer.dreheRechts(laufKommando);
	}

	private Kommando dreheLinksWennBelegt(SpielHelfer spielHelfer, Kommando laufKommando) {
		Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
		if (!spielHelfer.isPositionObstacle(laufPosition)) {
			return laufKommando;
		}
		// Feld ist belegt -> umlaufen
		return spielHelfer.dreheLinks(laufKommando);
	}

	@Override
	public void goToStartPosition(SpielHelfer spielHelfer) {
		position.setTo(spielHelfer.getMittelpunkt());
		position.x--;
	}

	@Override
	public Position getPosition() {
		return position;
	}

	@Override
	public void setIndex(int index) {
		myIndex = index;
	}

}
