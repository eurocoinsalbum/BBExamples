
public class Main {

	public static void main(String[] args) {
		Roboter roboter = new Roboter();
		Spiel spiel = new Spiel();
		spiel.addRoboter(roboter);
		Schwierigkeit schwierigkeit = roboter.getSchwierigkeit();
		if (schwierigkeit == Schwierigkeit.S1_KEIN_GEGNER) {
			// kein Gegner
		} else if (schwierigkeit == Schwierigkeit.S2_STEHT_RUM) {
			spiel.addRoboter(new RoboterS2StehtRum());
		} else if (schwierigkeit == Schwierigkeit.S3_SCHIESST_TOR) {
			spiel.addRoboter(new RoboterS3SchiesstTor());
		} else if (schwierigkeit == Schwierigkeit.S4_DRIBBELT) {
			spiel.addRoboter(new RoboterS4Dribbelt());
		}
		spiel.start();
	}

}
