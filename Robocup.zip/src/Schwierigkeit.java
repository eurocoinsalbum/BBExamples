
public enum Schwierigkeit {
	S1_KEIN_GEGNER, S2_STEHT_RUM, S3_SCHIESST_TOR, S4_DRIBBELT
}
