

public class RoboterS3SchiesstTor implements RoboterInterface {
	private final Position position = new Position();

	@Override
	public Schwierigkeit getSchwierigkeit() {
		return Schwierigkeit.S3_SCHIESST_TOR;
	}
	
	@Override
	public Kommando getKommando(SpielHelfer spielHelfer) {
		Position ball = spielHelfer.getBall();
		
		// Ball runter-rechts-dribbeln
		if (ball.y <= Spiel.GOAL1_A.y) {
			Position dribblingPosition = spielHelfer.calcPosition(ball, Kommando.RIGHT_UP);
			Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
			if (kommando != null) {
				return dreheLinksWennBelegt(spielHelfer, kommando);
			}
			return dreheLinksWennBelegt(spielHelfer, Kommando.LEFT_DOWN);
		}

		// Ball hoch-rechts-dribbeln
		if (ball.y >= Spiel.GOAL1_B.y) {
			Position dribblingPosition = spielHelfer.calcPosition(ball, Kommando.RIGHT_DOWN);
			Kommando kommando = spielHelfer.calcRichtung(position, dribblingPosition);
			if (kommando != null) {
				return dreheLinksWennBelegt(spielHelfer, kommando);
			}
			return dreheLinksWennBelegt(spielHelfer, Kommando.LEFT_UP);
		}
		
		// In Schussposition bringen
		Position schussPosition = spielHelfer.calcPosition(ball, Kommando.RIGHT);
		Kommando laufKommando = spielHelfer.calcRichtung(position, schussPosition);
		if (laufKommando != null) {
			Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
			// avoid moving the ball into the wrong direction while running to schussPosition
			if (spielHelfer.getBall().machtes(laufPosition)) {
				return spielHelfer.dreheLinks(laufKommando);
			}
			if (!spielHelfer.isPositionObstacle(laufPosition)) {
				return laufKommando;
			}
			// Feld ist belegt -> umlaufen
			return spielHelfer.dreheLinks(laufKommando);
		}
		return Kommando.KICK;
	}

	private Kommando dreheLinksWennBelegt(SpielHelfer spielHelfer, Kommando laufKommando) {
		Position laufPosition = spielHelfer.calcPosition(position, laufKommando);
		if (!spielHelfer.isPositionObstacle(laufPosition)) {
			return laufKommando;
		}
		// Feld ist belegt -> umlaufen
		return spielHelfer.dreheLinks(laufKommando);
	}

	@Override
	public void goToStartPosition(SpielHelfer spielHelfer) {
		position.setTo(spielHelfer.getMittelpunkt());
		position.x += 3;
	}

	@Override
	public Position getPosition() {
		return position;
	}
	
	@Override
	public void setIndex(int index) {
	}

}
