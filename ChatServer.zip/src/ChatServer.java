import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

class ChatServer {
	public static void main(String argv[]) {
		try {
			new ChatServer();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	

	private class ChatClientOnServer {
		public String nickName;
		public StringBuilder buffer;

		public ChatClientOnServer() {
			buffer = new StringBuilder();
		}
	}
	
	private HashMap<SocketChannel, ChatClientOnServer> clientMap = new HashMap<>();
	private CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
	private CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();

	public ChatServer() throws IOException {
		int serverPort = 81;
		Selector selector = Selector.open();
		ServerSocketChannel serverChannel = ServerSocketChannel.open();
		serverChannel.configureBlocking(false);
		serverChannel.socket().bind(new InetSocketAddress("localhost", serverPort));
		serverChannel.register(selector, SelectionKey.OP_ACCEPT);
		System.out.println("Server started. Waiting for connection on port " + serverPort);
		
		while (true) {
			selector.select();
			Iterator<SelectionKey> selectionKeys = selector.selectedKeys().iterator();
			while (selectionKeys.hasNext()) {
				SelectionKey selectionKey = selectionKeys.next();
				selectionKeys.remove();
				if (!selectionKey.isValid()) {
					continue;
				}
				if (selectionKey.isAcceptable()) {
					connectClient(selectionKey, selector);
					continue;
				}
				if (selectionKey.isReadable()) {
					try {
						readFromClient(selectionKey);
					} catch (IOException e) {
						disconnectClient((SocketChannel) selectionKey.channel());
					}
					continue;
				}
			}
		}		
	}

	private void readFromClient(SelectionKey key) throws IOException {
		SocketChannel clientChannel = (SocketChannel)key.channel();
		ByteBuffer buffer = ByteBuffer.allocate(1000);
		int readBytes = clientChannel.read(buffer);
		if (readBytes == -1) {
			clientMap.remove(clientChannel);
			System.out.println(clientChannel.socket().getRemoteSocketAddress()+ " closed connection.");
			clientChannel.close();
			key.cancel();
			return;
		}
		
		ChatClientOnServer chatClient = clientMap.get(clientChannel);
		buffer.flip();
		chatClient.buffer.append(decoder.decode(buffer).toString());
		
		if (chatClient.buffer.toString().endsWith("\n")) {
			chatClient.buffer.deleteCharAt(chatClient.buffer.length() - 1);
			// The first message of the client has to be his nick name
			if (chatClient.nickName == null) {
				chatClient.nickName = chatClient.buffer.toString();
				sendMessage(chatClient.nickName + " joined the room.", chatClient.nickName, "Your nickname is now: " + chatClient.nickName);
			} else {
				sendMessage(chatClient.nickName + ": " + chatClient.buffer.toString(), null, null);
			}
			chatClient.buffer = new StringBuilder();
		}
	}

	private void sendMessage(String message, String excludeNickName, String excludeMessage) {
		for (Entry<SocketChannel, ChatClientOnServer> entrySet : clientMap.entrySet()) {
			if (entrySet.getValue().nickName == null) {
				continue;
			}
			if (entrySet.getValue().nickName.equals(excludeNickName)) {
				System.out.println("Sending to " + entrySet.getValue().nickName + ": " + excludeMessage);
				sendMessage(entrySet.getKey(), excludeMessage);
				continue;
			}
			System.out.println("Sending to " + entrySet.getValue().nickName + ": " + message);
			sendMessage(entrySet.getKey(), message);
		}
	}

	private void sendMessage(SocketChannel clientChannel, String message) {
		try {
			clientChannel.write(encoder.encode(CharBuffer.wrap(message + "\n")));
		} catch (Exception e) {
			e.printStackTrace();
			disconnectClient(clientChannel);
		}
	}

	private void disconnectClient(SocketChannel clientChannel) {
		try {
			clientChannel.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			clientMap.remove(clientChannel);
		}
	}

	private void connectClient(SelectionKey selectionKey, Selector selector) throws IOException {
		ServerSocketChannel serverChannel = (ServerSocketChannel)selectionKey.channel();
		SocketChannel clientChannel = serverChannel.accept();
		clientChannel.configureBlocking(false);
		SocketAddress clientAddres = clientChannel.socket().getRemoteSocketAddress();
		System.out.println(clientAddres + " connected");
		clientMap.put(clientChannel, new ChatClientOnServer());
		clientChannel.register(selector, SelectionKey.OP_READ);
		sendMessage(clientChannel, "Welcome! Please enter your name.");
	}

}