import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

class Main {
	public static void main(String argv[]) {
		try {
			new Main();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	

	private class ChatClient {
		public String nickName;
		public StringBuilder buffer;

		public ChatClient() {
			buffer = new StringBuilder();
		}
	}
	
	private HashMap<SocketChannel, ChatClient> clientMap = new HashMap<>();
	private CharsetEncoder encoder = Charset.forName("US-ASCII").newEncoder();

	public Main() throws IOException {
		int serverPort = 81;
		Selector selector = Selector.open();
		ServerSocketChannel serverChannel = ServerSocketChannel.open();
		serverChannel.configureBlocking(false);
		serverChannel.socket().bind(new InetSocketAddress("localhost", serverPort));
		serverChannel.register(selector, SelectionKey.OP_ACCEPT);
		System.out.println("Server started. Waiting for connection on port " + serverPort);
		
		while (true) {
			selector.select();
			Iterator<SelectionKey> selectionKeys = selector.selectedKeys().iterator();
			while (selectionKeys.hasNext()) {
				SelectionKey selectionKey = selectionKeys.next();
				selectionKeys.remove();
				if (!selectionKey.isValid()) {
					continue;
				}
				if (selectionKey.isReadable()) {
					readFromClient(selectionKey);
					continue;
				}
				if (selectionKey.isAcceptable()) {
					connectClient(selectionKey, selector);
					continue;
				}
			}
		}		
	}

	private void readFromClient(SelectionKey key) throws IOException {
		SocketChannel clientChannel = (SocketChannel)key.channel();
		ByteBuffer buffer = ByteBuffer.allocate(1000);
		int readBytes = clientChannel.read(buffer);
		if (readBytes == -1) {
			clientMap.remove(clientChannel);
			System.out.println(clientChannel.socket().getRemoteSocketAddress()+ " closed connection.");
			clientChannel.close();
			key.cancel();
			return;
		}
		
		byte[] byteMessage = new byte[readBytes];
		System.arraycopy(buffer.array(), 0, byteMessage, 0, readBytes);
		ChatClient chatClient = clientMap.get(clientChannel);
		String text = new String(byteMessage);
		chatClient.buffer.append(text);
		
		if (text.endsWith("\r\n")) {
			chatClient.buffer.deleteCharAt(chatClient.buffer.length() - 1);
			chatClient.buffer.deleteCharAt(chatClient.buffer.length() - 1);
			// The first message of the client has to be his nick name
			if (chatClient.nickName == null) {
				chatClient.nickName = chatClient.buffer.toString();
				sendMessage(chatClient.nickName + " joined the room.");
			} else {
				sendMessage(chatClient.nickName + ": " + chatClient.buffer.toString());
			}
			chatClient.buffer = new StringBuilder();
		}
	}

	private void sendMessage(String message) {
		System.out.println(message);
		for (Entry<SocketChannel, ChatClient> entrySet : clientMap.entrySet()) {
			if (entrySet.getValue().nickName == null) {
				continue;
			}
			sendMessage(entrySet.getKey(), message);
		}
	}

	private void sendMessage(SocketChannel clientChannel, String message) {
		System.out.println(message);
		try {
			clientChannel.write(encoder.encode(CharBuffer.wrap(message + "\r\n")));
		} catch (Exception e) {
			e.printStackTrace();
			disconnectClient(clientChannel);
		}
	}

	private void disconnectClient(SocketChannel clientChannel) {
		try {
			clientChannel.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			clientMap.remove(clientChannel);
		}
	}

	private void connectClient(SelectionKey selectionKey, Selector selector) throws IOException {
		ServerSocketChannel serverChannel = (ServerSocketChannel)selectionKey.channel();
		SocketChannel clientChannel = serverChannel.accept();
		clientChannel.configureBlocking(false);
		SocketAddress clientAddres = clientChannel.socket().getRemoteSocketAddress();
		System.out.println(clientAddres + " connected");
		clientMap.put(clientChannel, new ChatClient());
		clientChannel.register(selector, SelectionKey.OP_READ);
		sendMessage(clientChannel, "Welcome! Please enter your name.");
	}

}