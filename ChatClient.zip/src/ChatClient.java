import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.nio.channels.spi.SelectorProvider;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

class Main {
	private static CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
	private static CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder();
	private static String messageToBeSent;
	private static StringBuilder messageReceived = new StringBuilder();
	private static Selector selector;
	private static SocketChannel socketChannel;

	public static void main(String argv[]) throws Exception {
		// Connect to chat server
		socketChannel = SocketChannel.open();
		socketChannel.configureBlocking(false);
		socketChannel.connect(new InetSocketAddress("localhost", 81));
		selector = SelectorProvider.provider().openSelector();
		socketChannel.register(selector, SelectionKey.OP_CONNECT);

		selector.select();
		boolean connected = false;
		Iterator<SelectionKey> selectedKeys = selector.selectedKeys().iterator();
		while (selectedKeys.hasNext()) {
			SelectionKey key = selectedKeys.next();
			selectedKeys.remove();
			if (!key.isValid()) {
				continue;
			}
			if (key.isConnectable()) {
				finishConnect(key);
				connected = true;
				key.interestOps(SelectionKey.OP_READ);
			}
		}
		
		if (!connected) {
			System.out.println("Not connected");
			System.exit(1);
		}

		// Build UI
		JFrame frame = new JFrame("BB-Chat");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container pane = frame.getContentPane();

		// message list
		DefaultListModel<String> defaultListModel = new DefaultListModel<String>();
		JList<String> list = new JList<>(defaultListModel);
		list.setLayoutOrientation(JList.VERTICAL_WRAP);
		list.setVisibleRowCount(-1);
		JScrollPane scrollPane = new JScrollPane(list);
		scrollPane.setPreferredSize(new Dimension(500, 500));
		pane.add(scrollPane, BorderLayout.CENTER);

		// text input + button
		JPanel cmdPanel = new JPanel(new BorderLayout());
		JTextField textField = new JTextField();
		cmdPanel.add(textField, BorderLayout.CENTER);
		JButton sendButton = new JButton("Send");
		cmdPanel.add(sendButton, BorderLayout.LINE_END);
		sendButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setMessageToBeSent(textField.getText());
				textField.setText("");
				socketChannel.keyFor(selector).interestOps(SelectionKey.OP_WRITE);
				selector.wakeup();
			}
		});
		pane.add(cmdPanel, BorderLayout.PAGE_END);

		frame.pack();
		frame.setVisible(true);

		while (true) {
			selector.select();
			selectedKeys = selector.selectedKeys().iterator();
            while (selectedKeys.hasNext()) {
                SelectionKey key = (SelectionKey) selectedKeys.next();
                selectedKeys.remove();

                if (!key.isValid()) {
                    continue;
                }

                // Check what event is available and deal with it
                if (key.isReadable()) {
                    String messageFromServer = readMessageFromServer(key);
                    if (messageFromServer != null) {
                    	System.out.println("Received from server: '" + messageFromServer + "'");
                    	defaultListModel.addElement(messageFromServer);
                        messageReceived(messageFromServer);
                    }
                } else if (key.isWritable()) {
                    writeMessageToServer(key, messageToBeSent);
                    messageToBeSent = null;
                }
            }
		}
	}


	protected static void setMessageToBeSent(String message) {
		messageToBeSent = message;
		socketChannel.keyFor(selector).interestOps(SelectionKey.OP_WRITE);
	}

	private static String readMessageFromServer(SelectionKey key) {
		SocketChannel socketChannel = (SocketChannel) key.channel();
		ByteBuffer buffer = ByteBuffer.allocate(1024);
		int numRead;
        try {
            numRead = socketChannel.read(buffer);
        } catch (IOException e) {
            key.cancel();
            try {
				socketChannel.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
            return null;
        }

        if (numRead == -1) {
            try {
				key.channel().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
            key.cancel();
            return null;
        }

        buffer.flip();
        try {
			messageReceived.append(decoder.decode(buffer).toString());
		} catch (CharacterCodingException e) {
			e.printStackTrace();
			return null;
		}
        
        if (messageReceived.toString().endsWith("\n")) {
        	String message = messageReceived.toString();
        	messageReceived = new StringBuilder();
	        message = message.trim();
	        return message;
        }
        return null;
	}

	private static void writeMessageToServer(SelectionKey key, String messageToBeSent) {
		SocketChannel socketChannel = (SocketChannel) key.channel();
		try {
			System.out.println("Sending to server: '" + messageToBeSent + "'");
			socketChannel.write(encoder.encode(CharBuffer.wrap(messageToBeSent + "\n")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		key.interestOps(SelectionKey.OP_READ);
	}

	private static void finishConnect(SelectionKey key) {
		SocketChannel socketChannel = (SocketChannel) key.channel();
		try {
			socketChannel.finishConnect();
		} catch (IOException e) {
			System.out.println(e);
			key.cancel();
			System.exit(1);
		}
	}

	private static void messageReceived(String messageFromServer) {
		// Hier kannst Du irgendwas programmieren, um automatisch Nachrichten zu senden. Nutze: setMessageToBeSent("bla bla");

	}

}