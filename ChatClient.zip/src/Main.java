import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

class Main {
	public static void main(String argv[]) throws Exception {
		// Connect to chat server
		Socket socket = new Socket("localhost", 81);
		DataOutputStream serverOutputStream = new DataOutputStream(socket.getOutputStream());
		BufferedReader serverInputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));

		// Build UI
		JFrame frame = new JFrame("BB-Chat");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container pane = frame.getContentPane();

		// message list
		JList<String> list = new JList<>();
		list.setLayoutOrientation(JList.VERTICAL_WRAP);
		list.setVisibleRowCount(-1);
		JScrollPane scrollPane = new JScrollPane(list);
		scrollPane.setPreferredSize(new Dimension(500, 500));
		pane.add(scrollPane, BorderLayout.CENTER);
		
		// text input + button
		JPanel cmdPanel = new JPanel(new BorderLayout());
		JTextField textField = new JTextField();
		cmdPanel.add(textField, BorderLayout.CENTER);
		JButton sendButton = new JButton("Send");
		sendButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					serverOutputStream.writeBytes(textField.getText() + "\r\n");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		pane.add(cmdPanel, BorderLayout.PAGE_END);
		
		frame.pack();
		frame.setVisible(true);

		while(true) {
			break;
		}
		String consoleText = serverInputStream.readLine();
		serverOutputStream.writeBytes(consoleText + '\n');
		String serverMessage = serverInputStream.readLine();
		socket.close();
	}
}